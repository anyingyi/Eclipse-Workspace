public enum EMethodType {
	RANDOM, SA, TA, NM, GA, PBIL,PSO
}
